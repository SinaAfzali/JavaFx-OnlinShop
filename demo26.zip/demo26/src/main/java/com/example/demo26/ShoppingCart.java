package com.example.demo26;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ShoppingCart extends Application {
    private ObservableList<Item> cartItems = FXCollections.observableArrayList();
    private ListView<Item> cartListView;
    private Label totalPriceLabel;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Shopping Cart");

        // Create UI components
        cartListView = new ListView<>();
        cartListView.setItems(cartItems);
        cartListView.setCellFactory(param -> new ListCell<Item>() {
            @Override
            protected void updateItem(Item item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(item.getName());
                }
            }
        });
        cartListView.setOnMouseClicked(event -> {
            Item selectedItem = cartListView.getSelectionModel().getSelectedItem();
            if (selectedItem != null) {
                // Logic to handle item selection and navigation to the corresponding item page
                System.out.println("Navigating to item page: " + selectedItem.getName());
            }
        });

        Label cartLabel = new Label("Cart Items:");
        Label totalLabel = new Label("Total Price:");
        totalPriceLabel = new Label();

        Button increaseButton = new Button("+");
        increaseButton.setOnAction(event -> increaseQuantity());

        Button decreaseButton = new Button("-");
        decreaseButton.setOnAction(event -> decreaseQuantity());

        Button checkoutButton = new Button("Checkout");
        checkoutButton.setOnAction(event -> {
            // Logic to handle checkout and navigate to the payment page
            System.out.println("Proceeding to Payment");
        });

        VBox vbox = new VBox(10);
        vbox.setPadding(new Insets(10));
        vbox.getChildren().addAll(cartLabel, cartListView, totalLabel, totalPriceLabel, increaseButton, decreaseButton, checkoutButton);

        updateTotalPrice(); // Update the total price label initially

        Scene scene = new Scene(vbox, 300, 400);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void updateTotalPrice() {
        double totalPrice = calculateTotalPrice();
        totalPriceLabel.setText("$" + totalPrice);
    }

    private double calculateTotalPrice() {
        double totalPrice = 0;
        for (Item item : cartItems) {
            totalPrice += item.getPrice() * item.getQuantity();
        }
        return totalPrice;
    }

    private void increaseQuantity() {
        Item selectedItem = cartListView.getSelectionModel().getSelectedItem();
        if (selectedItem != null) {
            selectedItem.setQuantity(selectedItem.getQuantity() + 1);
            updateTotalPrice();
        }
    }

    private void decreaseQuantity() {
        Item selectedItem = cartListView.getSelectionModel().getSelectedItem();
        if (selectedItem != null && selectedItem.getQuantity() > 1) {
            selectedItem.setQuantity(selectedItem.getQuantity() - 1);
            updateTotalPrice();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}

class Item {
    private String name;
    private double price;
    private int quantity;

    public Item(String name, double price, int quantity) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Override
    public String toString() {
        return name + " - $" + price + " x " + quantity;
    }
}
