package com.example.demo26;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class ProductPageController {

    @FXML
    private Button addToCartButton;

    @FXML
    private TextField scoreField;

    @FXML
    private TextArea commentArea;

    @FXML
    private Button submitButton;

    private boolean addedToCart = false;

    // This method is called when the FXML file is loaded
    @FXML
    public void initialize() {
        // Perform initialization tasks here
        // Set up event handlers for the buttons

        addToCartButton.setOnAction(e -> addToCart());
        submitButton.setOnAction(e -> submitCommentAndScore());
    }

    // Add the product to the cart
    private void addToCart() {
        if (!addedToCart) {
            // Add the product to the cart
            // Implement your logic here
            addToCartButton.setText("Remove from Cart");
            addedToCart = true;
        } else {
            // Remove the product from the cart
            // Implement your logic here
            addToCartButton.setText("Add to Cart");
            addedToCart = false;
        }
    }

    // Submit the user's comment and score
    private void submitCommentAndScore() {
        int score = Integer.parseInt(scoreField.getText());
        String comment = commentArea.getText();

        // Store the comment and score
        // Implement your logic here
    }
}
