package com.example.OnlineShop;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;

public final class wareHouseController {

    @FXML
    private TextField addressField;

    @FXML
    private Label addressLabel;

    @FXML
    private Button createButton;

    @FXML
    private GridPane grid;

    @FXML
    private Pane infoPane;

    @FXML
    private Label nameLabel;

    @FXML
    private TextField namefield;

    @FXML
    private AnchorPane warehousePane;

    boolean change=false;
    @FXML
    void addWareHouse(ActionEvent event) {
        if (!change) {
            infoPane.setVisible(true);
            infoPane.setStyle("-fx-background-color: #07aef5");
            change=true;
        }
        else if (change){
            infoPane.setVisible(false);
            infoPane.setStyle("-fx-background-color: null");
            change=false;
        }

        setWarehouse();

    }

    @FXML
    void back(MouseEvent event) {

    }

    @FXML
    void createButton(ActionEvent event) {

        Information.getWareHouses().add(new wareHouse(namefield.getText(),addressField.getText(),"akbar"));

        infoPane.setVisible(false);

        setWarehouse();

        change=false;

    }

    public void setWarehouse(){


        for (int i=0;i<Information.getProducts().size();i++){
            int j=i;
            grid.getChildren().removeIf(node -> GridPane.getRowIndex(node)==j/4 && GridPane.getColumnIndex(node)==j%4);
        }

        for (int i=0;i<Information.getWareHouses().size();i++){

            warehousePane.setPrefHeight((i+1)*60);
            grid.setPrefHeight((i+1)*60);
            Button numberLabel=new Button(String.valueOf(Information.getWareHouses().get(i).getProductsInWareHouse().size()));
            numberLabel.setPrefSize(120,60);
            Button managerLabel=new Button(Information.getWareHouses().get(i).getManager());
            managerLabel.setPrefSize(150,60);
            Button addressLabel=new Button(Information.getWareHouses().get(i).getAddress());
            addressLabel.setPrefSize(250,60);
            Button nameLabel=new Button(Information.getWareHouses().get(i).getName());
            nameLabel.setPrefSize(150,60);
            HBox hBox=new HBox(nameLabel,addressLabel,managerLabel,numberLabel);
            grid.add(hBox,0,i);

        }
    }

}
