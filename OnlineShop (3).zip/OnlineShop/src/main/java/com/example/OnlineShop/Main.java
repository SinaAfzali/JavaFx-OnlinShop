package com.example.OnlineShop;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Random;


public final class Main extends Application {
    @Override
    public void start(Stage primaryStage) throws IOException, SQLException {

//        Information.getProducts().add(new Product("روغن مایع",4,60000,"src/main/resources/com/example/image/1.jpg",Methods.returnCategory(6),"800 گرمی لادن بدون پالم","sina"));
//        Information.getProducts().add(new Product("کیسه برنج",5,650000,"src/main/resources/com/example/image/2.jpg",Methods.returnCategory(6)," ده کیلوگرمی طبیعت","sina"));
//        Information.getProducts().add(new Product("شیر کم چرب",10,30000,"src/main/resources/com/example/image/3.jpg",Methods.returnCategory(4),"یک و نیم لیتری میهن","sina"));
//        Information.getProducts().add(new Product("حبوبات",6,75000,"src/main/resources/com/example/image/4.jpg",Methods.returnCategory(6),"بسته یک و نیم کیلویی","sina"));
//        Information.getProducts().add(new Product("پفک نمکی",12,15000,"src/main/resources/com/example/image/5.jpg",Methods.returnCategory(9),"حاوی پودر پنیر","sina"));
//        Information.getProducts().add(new Product("نوشابه کوکاکولا",25,25000,"src/main/resources/com/example/image/6.jpg",Methods.returnCategory(1),"یک و نیم لیتری گازدار","sina"));
//        Information.getProducts().add(new Product("مزمز",8,20000,"src/main/resources/com/example/image/7.jpg",Methods.returnCategory(7),"مغز تخمه آفتابگردان","sina"));
//        Information.getProducts().get(0).setScore(4.48);
//        Information.getProducts().get(1).setScore(3.55);
//        Information.getProducts().get(2).setScore(4.9);
//        Information.getProducts().get(3).setScore(4.75);
//        Information.getProducts().get(4).setScore(3.32);
//        Information.getProducts().get(5).setScore(2.65);
//        Information.getProducts().get(6).setScore(4.22);

        Information.getWareHouses().add(new wareHouse("food","Tehran","sina"));
        Information.getWareHouses().add(new wareHouse("orange","mashhad","sasan"));


//        Person sina1=new Customer("sina","afzali","09331788813","sina1382","13821382","sinaafzali1382tj@gmail.com");
//        Person sina2=new Seller("sina","afzali","09331788813","sina1382","13821382","sinaafzali1382tj@gmail.com");


        Database.readPerson(Information.getPersons());

        Database.readProduct(Information.getProducts());

        Scene scene = new Scene(Methods.loader("MainPage.fxml").load(), 500, 600);
        Methods.stage.setScene(scene);
        Methods.stage.setFullScreen(true);
        Methods.stage.show();



    }

    public static void main(String[] args) {
        launch();
    }

}