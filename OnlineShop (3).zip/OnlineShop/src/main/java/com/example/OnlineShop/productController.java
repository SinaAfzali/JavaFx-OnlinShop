package com.example.OnlineShop;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseEvent;

public class productController {

    @FXML
    private Button point1;

    @FXML
    private Button point2;

    @FXML
    private Button point3;

    @FXML
    private Button point4;

    @FXML
    private Button point5;

    @FXML
    private TextArea theReciveBox;

    @FXML
    private TextArea theSendBox;

    @FXML
    void setBack(MouseEvent event) {

    }

    @FXML
    void setDecreas(ActionEvent event) {

    }

    @FXML
    void setIncreas(ActionEvent event) {

    }

    @FXML
    void setPoint(ActionEvent event) {

    }

    @FXML
    void setSend(ActionEvent event) {

    }

}
