package com.example.OnlineShop;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public final class AuctionController {

    @FXML
    private AnchorPane anchorPane;

    @FXML
    private ImageView backIcon;

    @FXML
    private GridPane grid;

    @FXML
    private TextField priceField;

    @FXML
    private Label setCodeSend;

    @FXML
    private Button showProduct;

    @FXML
    private TextField timeField;

    @FXML
    void create(ActionEvent event) {

    }

    public void showProduct(ActionEvent actionEvent) throws FileNotFoundException {
        grid.setHgap(30);
        grid.setVgap(50);
        for (int i=0;i<Information.getProducts().size();i++){
            int j=i;
            grid.getChildren().removeIf(node -> GridPane.getRowIndex(node)==j/2 && GridPane.getColumnIndex(node)==j%2);
        }
        int count=0;
        for (int i=0;i<Information.getProducts().size();i++){
            if (Information.getProducts().get(i).getUserNameSeller().equals(Information.getUserName()))count++;
        }
        int[]indexs=new int[count];
        count=0;
        for (int i=0;i<Information.getProducts().size();i++){
            if (Information.getProducts().get(i).getUserNameSeller().equals(Information.getUserName())){
                indexs[count]=i;
                count++;
            }
        }

        for (int i=0;i<indexs.length;i++) {
            anchorPane.setPrefHeight((i/2+1)*500);
            grid.setPrefHeight((i/2+1)*499.99);
            ImageView imageView = new ImageView(new Image(new FileInputStream(Information.getProducts().get(indexs[i]).getAddressImage())));
            Text text = new Text(Information.getProducts().get(indexs[i]).getName()+"\n"+Information.getProducts().get(indexs[i]).getDescription());
            text.setFont(Font.font("serif",20));
            text.setTextAlignment(TextAlignment.CENTER);
            Button select=new Button("انتخاب محصول");
            select.setFont(Font.font("serif",18));
            select.setStyle("-fx-background-color: #00ff00");
            int index = indexs[i];
            select.setOnAction(e -> {
                try {
                    selectProduct(index);
                } catch (FileNotFoundException ex) {
                    throw new RuntimeException(ex);
                }
            });
            Label label=new Label(Methods.moneyStandard(Information.getProducts().get(indexs[i]).getPrice())+" تومان");
            label.setPrefSize(250,100);
            label.setAlignment(Pos.CENTER);
            label.setPadding(new Insets(5));
            label.setFont(Font.font("serif",20));
            VBox vbox = new VBox(imageView, text,label,select);
            vbox.setAlignment(Pos.CENTER);
            vbox.setPrefSize(350,350);
            grid.add(vbox, i%2, i/2);
        }


    }

    private void selectProduct(int index) throws FileNotFoundException {
        grid.setHgap(30);
        grid.setVgap(50);
        for (int i=0;i<Information.getProducts().size();i++){
            int j=i;
            grid.getChildren().removeIf(node -> GridPane.getRowIndex(node)==j/2 && GridPane.getColumnIndex(node)==j%2);
        }
        anchorPane.setPrefHeight(370);
        grid.setPrefHeight(370);
        ImageView imageView = new ImageView(new Image(new FileInputStream(Information.getProducts().get(index).getAddressImage())));
        Text text = new Text(Information.getProducts().get(index).getName()+"\n"+Information.getProducts().get(index).getDescription());
        text.setFont(Font.font("serif",20));
        text.setTextAlignment(TextAlignment.CENTER);
        Label label=new Label(Methods.moneyStandard(Information.getProducts().get(index).getPrice())+" تومان");
        label.setPrefSize(250,100);
        label.setAlignment(Pos.CENTER);
        label.setPadding(new Insets(5));
        label.setFont(Font.font("serif",20));
        VBox vbox = new VBox(imageView, text,label);
        vbox.setAlignment(Pos.CENTER);
        vbox.setPrefSize(350,350);
        grid.add(vbox, 0, 0);
    }
}
