package com.example.OnlineShop;

import javafx.beans.binding.Bindings;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.PieChart;

import java.net.URL;
import java.util.ResourceBundle;

public class pieChartController implements Initializable {

    @FXML
    private PieChart pieChart;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ObservableList<PieChart.Data>pieChartDate =
                FXCollections.observableArrayList(
                  new PieChart.Data("sina",2),
                        new PieChart.Data("ali",4),
                        new PieChart.Data("mohammad",5)
                );

        pieChartDate.forEach(data -> data.nameProperty().bind(Bindings.concat(data.getName(),"amount",data.pieValueProperty())));


    }
}
