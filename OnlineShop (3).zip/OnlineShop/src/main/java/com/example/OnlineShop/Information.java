package com.example.OnlineShop;

import java.util.ArrayList;

public final class Information {

    private static ArrayList<Person>persons=new ArrayList<>();
    private static ArrayList<Product> products = new ArrayList<>();
    private static ArrayList<wareHouse> wareHouses = new ArrayList<>();

    public static ArrayList<Person> getPersons() {
        return persons;
    }

    public static ArrayList<Product> getProducts() {
        return products;
    }

    public static ArrayList<wareHouse> getWareHouses() {
        return wareHouses;
    }







    private static String userName="sina";

    private static String defaultWareHouse="FUM WareHouse";

    public static void setDefaultWareHouse(String defaultWareHouse) {
        Information.defaultWareHouse = defaultWareHouse;
    }

    public static String getDefaultWareHouse() {
        return defaultWareHouse;
    }

    private static int role;

    public static int getRole() {
        return role;
    }

    public static void setRole(int role) {
        Information.role = role;
    }

    public static String getUserName() {
        return userName;
    }

    public static void setUserName(String userName) {
        Information.userName = userName;
    }

    private static boolean Login=false;

    public static boolean isLogin() {
        return Login;
    }

    public static void setLogin(boolean login) {
        Login = login;
    }

}
