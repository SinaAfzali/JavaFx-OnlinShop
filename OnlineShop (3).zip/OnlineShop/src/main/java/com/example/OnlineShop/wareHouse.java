package com.example.OnlineShop;

import java.util.ArrayList;

public final class wareHouse {
    private String name;
    private String address;
    private String manager;
    private ArrayList<Product>productsInWareHouse=new ArrayList<>();

    public void setName(String name) {
        this.name = name;
    }

    public String getManager() {
        return manager;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public ArrayList<Product> getProductsInWareHouse() {
        return productsInWareHouse;
    }


    public String getAddress() {
        return address;
    }


    public wareHouse(String name,String address,String manager){
        this.name=name;
        this.address=address;
        this.manager=manager;
    }



}
