package com.example.OnlineShop;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;

public class CartController {

    @FXML
    private AnchorPane anchorPane;

    @FXML
    private ImageView backIcon;

    @FXML
    private GridPane grid;

    @FXML
    void disscountPage(ActionEvent event) {

    }

    @FXML
    void payPage(ActionEvent event) {

    }

}
