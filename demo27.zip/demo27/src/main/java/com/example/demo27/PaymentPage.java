package com.example.demo27;

import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class PaymentPage extends Stage {

    public PaymentPage() {
        setTitle("Payment");

        StackPane root = new StackPane();
        Scene scene = new Scene(root, 400, 400);

        setScene(scene);
    }
}
