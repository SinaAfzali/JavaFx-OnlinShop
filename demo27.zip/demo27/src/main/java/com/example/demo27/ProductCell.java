package com.example.demo27;

import javafx.scene.control.ListCell;

public class ProductCell extends ListCell<Product> {
    @Override
    protected void updateItem(Product product, boolean empty){
        super.updateItem(product, empty);
        if(empty || product == null){
            setText(null);
            setGraphic(null);
        }
        else {
            setText(product.getName());
            setGraphic(null);
        }
    }
}
