package com.example.demo27;

import javafx.application.Application;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.Objects;

public class ShoppingCartApp extends Application {

    private IntegerProperty totalItems;
    private DoubleProperty totalPrice;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Shopping Cart");

        // Initialize cart items
        ObservableList<Product> cartItems = FXCollections.observableArrayList();
        totalItems = new SimpleIntegerProperty(0);
        totalPrice = new SimpleDoubleProperty(0.0);

        // Create UI components
        ListView<Product> cartListView = new ListView<>(cartItems);
        cartListView.setCellFactory(param -> new CartItemCell(totalPrice, totalItems));
        Label totalItemsLabel = new Label();
        totalItemsLabel.textProperty().bind(totalItems.asString("Total Items: %d"));
        Label totalPriceLabel = new Label();
        totalPriceLabel.textProperty().bindBidirectional(totalPrice, new PriceStringConverter());
        Button checkoutButton = new Button("Proceed to Checkout");

        // Create layout
        VBox root = new VBox(10);
        root.setPadding(new Insets(10));
        root.setAlignment(Pos.CENTER);
        root.getStyleClass().add("root");
        root.getChildren().addAll(createBackButton(primaryStage), cartListView, totalItemsLabel, totalPriceLabel, createDiscountCardsButton(), createPaymentButton(checkoutButton));

        // Event handling
        cartListView.getSelectionModel().selectedItemProperty().addListener((obs, oldProduct, newProduct) -> {
            if (newProduct != null) {
                // Open the product page when a cart item is clicked
                openProductPage(newProduct);
                cartListView.getSelectionModel().clearSelection();
            }
        });

        checkoutButton.setOnAction(e -> proceedToCheckout());

        // Set the layout
        Scene scene = new Scene(root, 400, 400);
        scene.getStylesheets().add(Objects.requireNonNull(getClass().getResource("styles.css")).toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private Button createBackButton(Stage primaryStage) {
        // Create a back button/image to return to the previous page
        Button backButton = new Button("Back");
        backButton.getStyleClass().add("back-button");
        backButton.setOnAction(e -> {
            // Code to handle the back button action
            // Replace the code below with your implementation
            System.out.println("Back button clicked");
            primaryStage.close(); // Close the current window
            // Add code to open the previous page/window
        });
        return backButton;
    }

    private Button createDiscountCardsButton() {
        Button discountCardsButton = new Button("My Discount Cards");
        discountCardsButton.getStyleClass().add("discount-cards-button");
        discountCardsButton.setOnAction(e -> {
            // Create and show the discount cards page
            DiscountCardsPage discountCardsPage = new DiscountCardsPage();
            discountCardsPage.show();
        });
        return discountCardsButton;
    }

    private Button createPaymentButton(Button checkoutButton) {
        Button paymentButton = new Button("Payment");
        paymentButton.getStyleClass().add("payment-button");
        paymentButton.setOnAction(e -> {
            // Create and show the payment page
            PaymentPage paymentPage = new PaymentPage();
            paymentPage.show();
        });
        // Disable the payment button if the cart is empty
        paymentButton.disableProperty().bind(totalItems.isEqualTo(0));
        return paymentButton;
    }

    private void openProductPage(Product product) {
        // Code to open the product page for the selected product
        // Implement this method based on your application's requirements
        System.out.println("Opening product page for: " + product.getName());
    }

    private void proceedToCheckout() {
        // Code to proceed to the checkout page
        // Implement this method based on your application's requirements
        System.out.println("Proceeding to checkout...");
    }

    public void increaseTotalPrice(double amount) {
        totalPrice.set(totalPrice.get() + amount);
    }

    public void decreaseTotalPrice(double amount) {
        totalPrice.set(totalPrice.get() - amount);
    }
}
