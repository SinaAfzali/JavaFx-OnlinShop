package com.example.demo27;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.layout.HBox;

public class CartItemCell extends ListCell<Product> {

    private final DoubleProperty totalPriceProperty;
    private final IntegerProperty totalItemsProperty;

    public CartItemCell(DoubleProperty totalPriceProperty, IntegerProperty totalItemsProperty) {
        this.totalPriceProperty = totalPriceProperty;
        this.totalItemsProperty = totalItemsProperty;
    }

    @Override
    protected void updateItem(Product product, boolean empty) {
        super.updateItem(product, empty);

        if (empty || product == null) {
            setText(null);
            setGraphic(null);
        } else {
            HBox hbox = new HBox(10);
            Label nameLabel = new Label(product.getName());
            Label priceLabel = new Label();
            priceLabel.textProperty().bindBidirectional(product.priceProperty(), new PriceStringConverter());
            Button decreaseButton = new Button("-");
            Button increaseButton = new Button("+");

            decreaseButton.setOnAction(e -> {
                if (product.getQuantity() > 1) {
                    product.decreaseQuantity();
                    decreaseTotalPrice(product.getPrice());
                    totalItemsProperty.set(totalItemsProperty.get() - 1);
                }
            });

            increaseButton.setOnAction(e -> {
                product.increaseQuantity();
                increaseTotalPrice(product.getPrice());
                totalItemsProperty.set(totalItemsProperty.get() + 1);
            });

            hbox.getChildren().addAll(nameLabel, priceLabel, decreaseButton, increaseButton);
            setGraphic(hbox);
        }
    }

    private void increaseTotalPrice(double amount) {
        ShoppingCartApp app = (ShoppingCartApp) getListView().getScene().getWindow().getUserData();
        app.increaseTotalPrice(amount);
    }

    private void decreaseTotalPrice(double amount) {
        ShoppingCartApp app = (ShoppingCartApp) getListView().getScene().getWindow().getUserData();
        app.decreaseTotalPrice(amount);
    }
}