package com.example.demo27;

import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class DiscountCardsPage extends Stage {

    public DiscountCardsPage() {
        setTitle("My Discount Cards");

        StackPane root = new StackPane();
        Scene scene = new Scene(root, 400, 400);

        setScene(scene);
    }
}
