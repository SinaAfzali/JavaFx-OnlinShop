package com.example.demo27;

import javafx.util.StringConverter;

public class PriceStringConverter extends StringConverter<Number> {
    @Override
    public String toString(Number number) {
        return String.format("$%.2f", number.doubleValue());
    }

    @Override
    public Number fromString(String string) {
        throw new UnsupportedOperationException("Conversion from String to Number is not supported.");
    }
}
