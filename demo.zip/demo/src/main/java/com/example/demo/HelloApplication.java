package com.example.demo;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Border;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Random;

public class HelloApplication extends Application {
//    public void start(Stage stage) throws IOException {
//        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
//        Scene scene = new Scene(fxmlLoader.load(), 1000, 500);
//        stage.setTitle("Hello!");
//        stage.setScene(scene);
//        stage.setFullScreen(true);
//        stage.show();
//    }
@Override
    public void start(Stage primaryStage) {
    Hyperlink link = new Hyperlink();
    link.setText("https://soft98.ir");
    link.setOnAction(new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent e) {
            System.out.println("This link is clicked");
        }
    });
        // create grid pane
    ScrollPane scrollPane;
        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setHgap(20);
        gridPane.setVgap(20);
        gridPane.setPadding(new Insets(20));

        // create buttons and add them to grid pane
    int z=0;
        for (int i = 0; i < 300; i++) {
            if (i%8==4){
                for (int j=0;j<4;j++) {
                    Label label = new Label("price = "+new Random().nextInt(1000));
                    label.setPrefSize(200, 20);
                    gridPane.add(label, i % 4, i / 4);
                    i++;
                }
            }
            Image img = new Image("D:\\Programming\\intellij\\demo\\image\\"+(new Random().nextInt(4)+1)+".jpg");
            ImageView view = new ImageView(img);
            Button button = new Button();
            button.setPrefSize(250, 250);
            button.setGraphic(view);
            gridPane.add(button, i%4, i/4);
        }
        // create scene and set it to stage
        scrollPane=new ScrollPane(gridPane);
        Scene scene = new Scene(scrollPane);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Full Screen Buttons");
        primaryStage.setFullScreen(true);
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch();
    }
}