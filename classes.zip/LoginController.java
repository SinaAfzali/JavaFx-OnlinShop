package com.example.OnlineShop;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class LoginController {

    @FXML
    private TextField codeField;

    @FXML
    private Button loginButton;

    @FXML
    private TextField passField;

    @FXML
    private ImageView randomImage;

    @FXML
    private TextField userField;


    private String image = "src/main/resources/com/example/image/79199.png";


    @FXML
    void loginButton(ActionEvent event) throws IOException {
        userField.setStyle("-fx-border-color: white; -fx-border-width: 1px; -fx-background-radius: 20px; -fx-border-radius: 20px ");
        passField.setStyle("-fx-border-color: white; -fx-border-width: 1px; -fx-background-radius: 20px; -fx-border-radius: 20px ");
        codeField.setStyle("-fx-border-color: white; -fx-border-width: 1px; -fx-background-radius: 20px; -fx-border-radius: 20px ");

     //   Information.getCustomer().add(new Customer("sina", "afzali", "09331788813", "sina1382", "1234", "sinaafzali1382tj@gmail.com"));

        boolean permissionUserName = Methods.searchProperty("userName",userField.getText(),0);
        boolean permissionPassword = Methods.searchProperty("password",passField.getText(),0);
        boolean permissionCodeRand = false;


        if (codeField.getText().equals(Methods.codeImageRand(image))) permissionCodeRand = true;

        if (permissionUserName && permissionPassword && permissionCodeRand) {
            Methods.stage.close();
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Pay.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 500, 600);
            Methods.stage.setTitle("Pay");
            Methods.stage.setScene(scene);
            Methods.stage.setFullScreen(true);
            Methods.stage.show();
        } else if (permissionUserName && permissionPassword && !permissionCodeRand) {
            codeField.setStyle("-fx-border-color: red; -fx-border-width: 2px; -fx-background-radius: 20px; -fx-border-radius: 20px ");
        }
        else if (permissionUserName && permissionCodeRand && !permissionPassword){
            passField.setStyle("-fx-border-color: red; -fx-border-width: 2px; -fx-background-radius: 20px; -fx-border-radius: 20px ");
        }
        else if (permissionUserName && !permissionPassword && !permissionCodeRand){
            passField.setStyle("-fx-border-color: red; -fx-border-width: 2px; -fx-background-radius: 20px; -fx-border-radius: 20px ");
            codeField.setStyle("-fx-border-color: red; -fx-border-width: 2px; -fx-background-radius: 20px; -fx-border-radius: 20px ");
        }
        else {
            passField.setStyle("-fx-border-color: red; -fx-border-width: 2px; -fx-background-radius: 20px; -fx-border-radius: 20px ");
            codeField.setStyle("-fx-border-color: red; -fx-border-width: 2px; -fx-background-radius: 20px; -fx-border-radius: 20px ");
            userField.setStyle("-fx-border-color: red; -fx-border-width: 2px; -fx-background-radius: 20px; -fx-border-radius: 20px ");
        }
    }

    @FXML
    void refresh(MouseEvent event) throws FileNotFoundException {
        image = Methods.imageRand();
        randomImage.setImage(null);
        randomImage.setImage(new Image(new FileInputStream(image)));
    }

    @FXML
    void forget() throws IOException {
        Methods.stage.close();
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("forget.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 500, 600);
        Methods.stage.setTitle("forget");
        Methods.stage.setScene(scene);
        Methods.stage.setFullScreen(true);
        Methods.stage.show();
    }

    @FXML
    void signing() throws IOException {
        Methods.stage.close();
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("signing.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 500, 600);
        Methods.stage.setTitle("forget");
        Methods.stage.setScene(scene);
        Methods.stage.setFullScreen(true);
        Methods.stage.show();
    }

    @FXML
    void back(){

    }

}
