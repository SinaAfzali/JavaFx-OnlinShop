package com.example.OnlineShop;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

import java.io.IOException;

public class ForgetController {

    @FXML
    private TextField setCode;

    @FXML
    private TextField setPass;

    @FXML
    private TextField useEmail;

    @FXML
    void refresh(MouseEvent event) {

    }

    @FXML
    void setConfirm(ActionEvent event) {

    }

    @FXML
    void setReturn(MouseEvent event) throws IOException {
        Methods.stage.close();
        Scene scene = new Scene(Methods.loginLoader.load(), 500, 600);
        Methods.stage.setTitle("forget");
        Methods.stage.setScene(scene);
        Methods.stage.setFullScreen(true);
        Methods.stage.show();
    }

}
