package com.example.OnlineShop;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class CustomerAccountController {

    @FXML
    private TextField emailField;

    @FXML
    private TextField firstNameField;

    @FXML
    private TextField lastNameField;

    @FXML
    private Label moneyField;

    @FXML
    private TextField passField;

    @FXML
    private TextField phoneField;

    @FXML
    private TextField ruleField;

    @FXML
    private TextField userField;

    @FXML
    void setCart(ActionEvent event) {

    }

    @FXML
    void setChangeInformation(ActionEvent event) {

    }

    @FXML
    void setDiscountCode(ActionEvent event) {

    }


    @FXML
    void setMoney(ActionEvent event) {

    }

    @FXML
    void setRecords(ActionEvent event) {

    }

    @FXML
    void setReturn(MouseEvent event) {

    }

}
