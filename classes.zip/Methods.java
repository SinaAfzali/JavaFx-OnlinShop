package com.example.OnlineShop;

import javafx.stage.Stage;

import java.util.Random;

public class Methods {

    static Stage stage=new Stage();

    public String imageRand(){
        Random random=new Random();
        int rand=random.nextInt(15)+1;
        return switch (rand) {
            case 1 -> "src/main/resources/com/example/image/14726.png";
            case 2 -> "src/main/resources/com/example/image/17624.png";
            case 3 -> "src/main/resources/com/example/image/18543.png";
            case 4 -> "src/main/resources/com/example/image/79199.png";
            case 5 -> "src/main/resources/com/example/image/21695.png";
            case 6 -> "src/main/resources/com/example/image/28642.png";
            case 7 -> "src/main/resources/com/example/image/33697.png";
            case 8 -> "src/main/resources/com/example/image/34837.png";
            case 9 -> "src/main/resources/com/example/image/43481.png";
            case 10 -> "src/main/resources/com/example/image/53763.png";
            case 11 -> "src/main/resources/com/example/image/59788.png";
            case 12 -> "src/main/resources/com/example/image/63598.png";
            case 13 -> "src/main/resources/com/example/image/72696.png";
            case 14 -> "src/main/resources/com/example/image/82473.png";
            case 15 -> "src/main/resources/com/example/image/91758.png";
            default -> "";
        };
    }

    public String codeImageRand(String image){
        switch (image){
            case "src/main/resources/com/example/image/14726.png":return "14726";
            case "src/main/resources/com/example/image/17624.png":return "17624";
            case "src/main/resources/com/example/image/18543.png":return "18543";
            case "src/main/resources/com/example/image/79199.png":return "79199";
            case "src/main/resources/com/example/image/21695.png":return "21695";
            case "src/main/resources/com/example/image/28642.png":return "28642";
            case "src/main/resources/com/example/image/33697.png":return "33697";
            case "src/main/resources/com/example/image/34837.png":return "34837";
            case "src/main/resources/com/example/image/43481.png":return "43481";
            case "src/main/resources/com/example/image/53763.png":return "53763";
            case "src/main/resources/com/example/image/59788.png":return "59788";
            case "src/main/resources/com/example/image/63598.png":return "63598";
            case "src/main/resources/com/example/image/72696.png":return "72696";
            case "src/main/resources/com/example/image/82473.png":return "82473";
            case "src/main/resources/com/example/image/91758.png":return "91758";
            default:return "";
        }
    }

   public boolean searchProperty(String item , String value , int role){
       for (int i=0;i<Information.getCustomer().size();i++){
           if (item.equals(Information.getCustomer().get(i).getUserName()))return true;
       }
           switch (item){
               case "userName":
               if(role==1 || role==0){
                   for (int i = 0; i < Information.getCustomer().size(); i++) {
                       if (value.equals(Information.getCustomer().get(i).getUserName())) return true;
                   }
               }
               if (role==2 || role==0){
                   for (int i = 0; i < Information.getSeller().size(); i++) {
                       if (value.equals(Information.getSeller().get(i).getUserName())) return true;
                   }
               }
               case "password":
                   if(role==1 || role==0){
                       for (int i = 0; i < Information.getCustomer().size(); i++) {
                           if (value.equals(Information.getCustomer().get(i).getPassword())) return true;
                       }
                   }
                   if (role==2 || role==0){
                       for (int i = 0; i < Information.getSeller().size(); i++) {
                           if (value.equals(Information.getSeller().get(i).getPassword())) return true;
                       }
                   }
               case "email":
                   if(role==1 || role==0){
                       for (int i = 0; i < Information.getCustomer().size(); i++) {
                           if (value.equals(Information.getCustomer().get(i).getEmail())) return true;
                       }
                   }
                   if (role==2 || role==0){
                       for (int i = 0; i < Information.getSeller().size(); i++) {
                           if (value.equals(Information.getSeller().get(i).getEmail())) return true;
                       }
                   }
           }
        return false;
   }


    public boolean checkFieldText(String s){
        for (int i=0;i<s.length();i++){
            if (s.charAt(i)>'9' || s.charAt(i)<'0')return false;
        }
        return true;
    }

}
