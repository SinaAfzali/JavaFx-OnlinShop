package com.example.OnlineShop;

import java.util.ArrayList;

public class Information {
  private static ArrayList<Customer>Customer=new ArrayList<>();

    private static ArrayList<Seller>Seller=new ArrayList<>();
    public static ArrayList<com.example.OnlineShop.Customer> getCustomer() {
        return Customer;
    }

    public static ArrayList<com.example.OnlineShop.Seller> getSeller() {
        return Seller;
    }
}
