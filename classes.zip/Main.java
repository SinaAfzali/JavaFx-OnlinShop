package com.example.OnlineShop;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;
public class Main extends Application {
    @Override
    public void start(Stage primaryStage) throws IOException {
        Scene scene = new Scene(Methods.loginLoader.load(), 500, 600);
        Methods.stage.setTitle("Login");
        Methods.stage.setScene(scene);
        Methods.stage.setFullScreen(true);
        Methods.stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}