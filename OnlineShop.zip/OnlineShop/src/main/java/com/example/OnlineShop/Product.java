package com.example.OnlineShop;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;

import java.util.ArrayList;

public class Product {
    public static class Comments{
        String userName;
        String textComment;
        boolean bought;

        public Comments(String userName,String textComment,boolean bought){
            this.userName=userName;
            this.textComment=textComment;
            this.bought=bought;
        }
    }


    //نام محصول
    private String name;
    //تعداد محصول
    private int quantity;
    //قیمت محصول
    private double price;
    //امتیاز محصول
    private double score=0;
    //آدرس عکس محصول
    private String addressImage;
    //دسته بندی محصول
    private String category;

    //توضیحات محصول
    private String description;

    //تعداد در سبد خرید
    private int numberInCart=0;
    //نظرات درباره محصول
    private  ArrayList<Comments>comments=new ArrayList<>();
    //کسانی که این محصول را خریده اند
    private ArrayList<String>buyers=new ArrayList<>();

    public Product(String name,int quantity,double price,String addressImage,String category,String description){
        setName(name);
        setQuantity(quantity);
        setPrice(price);
        setAddressImage(addressImage);
        setCategory(category);
        setDescription(description);
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setScore(double score) {
        this.score = score;
    }

    public void setAddressImage(String addressImage) {
        this.addressImage = addressImage;
    }

    public void setBuyers(ArrayList<String> buyers) {
        this.buyers = buyers;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setComments(ArrayList<Comments> comments) {
        this.comments = comments;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setNumberInCart(int numberInCart) {
        this.numberInCart = numberInCart;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public ArrayList<Comments> getComments() {
        return comments;
    }

    public ArrayList<String> getBuyers() {
        return buyers;
    }

    public double getScore() {
        return score;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getAddressImage() {
        return addressImage;
    }

    public String getCategory() {
        return category;
    }

    public String getDescription() {
        return description;
    }

    public int getNumberInCart() {
        return numberInCart;
    }
    public DoubleProperty priceProperty() {
        return new SimpleDoubleProperty(price);
    }
}
