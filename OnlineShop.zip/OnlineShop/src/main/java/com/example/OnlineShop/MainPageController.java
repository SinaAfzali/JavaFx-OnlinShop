package com.example.OnlineShop;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;

public class MainPageController {
    @FXML
    private TextField minHide;
    @FXML
    private TextField maxHide;
    @FXML
    private Button applyFilter;
    @FXML
    private Pane pricePane;
    private ArrayList<Label>quantity=new ArrayList<>();

    @FXML
    private AnchorPane anchorPane;

    @FXML
    private Button brand;

    @FXML
    private Button cheapest;

    @FXML
    private Button expensive;

    @FXML
    private GridPane grid;

    @FXML
    private Button newest;

    @FXML
    private Button price;

    @FXML
    private Button score;


    @FXML
    void beverages(ActionEvent event) {

    }

    @FXML
    void brand(ActionEvent event) {

    }

    @FXML
    void breakFast(ActionEvent event) {

    }


    public void setEmpty(){
        for (int i=0;i<Information.getProducts().size();i++){
            int j=i;
            grid.getChildren().removeIf(node -> GridPane.getRowIndex(node)==j/4 && GridPane.getColumnIndex(node)==j%4);
        }
    }

    public void selectedNewest() throws FileNotFoundException {

        setEmpty();
        grid.setHgap(30);
        grid.setVgap(50);
        grid.setPadding(new Insets(50));

        for (int i=Information.getProducts().size()-1;i>=0;i--) {
            int j=Information.getProducts().size()-i-1;
            anchorPane.setPrefHeight((j/4+1)*500);
            grid.setPrefHeight((j/4+1)*499.99);
            ImageView imageView = new ImageView(new Image(new FileInputStream(Information.getProducts().get(i).getAddressImage())));
            Text text = new Text(Information.getProducts().get(i).getName()+"\n"+Information.getProducts().get(i).getDescription());
            text.setFont(Font.font("serif",20));
            text.setTextAlignment(TextAlignment.CENTER);
            Button minus=new Button("-");
            minus.setFont(Font.font("serif",18));
            minus.setStyle("-fx-background-color: #ff0000");
            int index = i;
            minus.setOnAction(e -> {
                minus(index,j);
            });
            quantity.add(new Label());
            if (Information.getProducts().get(i).getNumberInCart()==0)quantity.get(j).setText("افزودن به سبد");
            else quantity.get(j).setText("تعداد : "+Information.getProducts().get(j).getNumberInCart());
            quantity.get(j).setFont(Font.font("Arial",20));
            quantity.get(j).setPrefSize(100,35);
            quantity.get(j).setAlignment(Pos.CENTER);
            Button plus=new Button("+");
            plus.setFont(Font.font("serif",18));
            plus.setStyle("-fx-background-color: #00ff00");
            plus.setOnAction(e -> {
                plus(index,j);
            });
            HBox hBox=new HBox(minus,quantity.get(j),plus);
            hBox.setAlignment(Pos.CENTER);
            Label label=new Label(Methods.moneyStandard(Information.getProducts().get(i).getPrice())+" تومان");
            label.setPrefSize(250,100);
            label.setAlignment(Pos.CENTER);
            label.setPadding(new Insets(5));
            label.setFont(Font.font("serif",20));
            VBox vbox = new VBox(imageView, text,label, hBox);
            vbox.setAlignment(Pos.CENTER);
            vbox.setPrefSize(350,350);
            grid.add(vbox, j%4, j/4);
        }
    }


    public void setProduct(int type) throws FileNotFoundException {
        grid.setHgap(30);
        grid.setVgap(50);
        grid.setPadding(new Insets(50));
        for (int i=0;i<Information.getProducts().size();i++){
            int j=i;
            grid.getChildren().removeIf(node -> GridPane.getRowIndex(node)==j/4 && GridPane.getColumnIndex(node)==j%4);
        }
        quantity=new ArrayList<>();
        int[]indexs= Methods.sortBy(Information.getProducts(),type);
        for (int i=0;i<indexs.length;i++) {
            anchorPane.setPrefHeight((i/4+1)*500);
            grid.setPrefHeight((i/4+1)*499.99);
            ImageView imageView = new ImageView(new Image(new FileInputStream(Information.getProducts().get(indexs[i]).getAddressImage())));
            Text text = new Text(Information.getProducts().get(indexs[i]).getName()+"\n"+Information.getProducts().get(indexs[i]).getDescription());
            text.setFont(Font.font("serif",20));
            text.setTextAlignment(TextAlignment.CENTER);
            Button minus=new Button("-");
            minus.setFont(Font.font("serif",18));
            minus.setStyle("-fx-background-color: #ff0000");
            int index = i;
            minus.setOnAction(e -> {
                minus(index,index);
            });
            quantity.add(new Label());
            if (Information.getProducts().get(indexs[i]).getNumberInCart()==0)quantity.get(i).setText("افزودن به سبد");
            else quantity.get(i).setText("تعداد : "+Information.getProducts().get(indexs[i]).getNumberInCart());
            quantity.get(i).setFont(Font.font("Arial",20));
            quantity.get(i).setPrefSize(100,35);
            quantity.get(i).setAlignment(Pos.CENTER);
            Button plus=new Button("+");
            plus.setFont(Font.font("serif",18));
            plus.setStyle("-fx-background-color: #00ff00");
            plus.setOnAction(e -> {
                plus(index,index);
            });
            HBox hBox=new HBox(minus,quantity.get(i),plus);
            hBox.setAlignment(Pos.CENTER);
            Label label=new Label(Methods.moneyStandard(Information.getProducts().get(indexs[i]).getPrice())+" تومان");
            label.setPrefSize(250,100);
            label.setAlignment(Pos.CENTER);
            label.setPadding(new Insets(5));
            label.setFont(Font.font("serif",20));
            VBox vbox = new VBox(imageView, text,label, hBox);
            vbox.setAlignment(Pos.CENTER);
            vbox.setPrefSize(350,350);
            grid.add(vbox, i%4, i/4);
        }
    }


    @FXML
    void cheapest(ActionEvent event) throws FileNotFoundException {
        setProduct(1);
        cheapest.setStyle("-fx-background-color: #019eff");
        expensive.setStyle("-fx-background-color: #b6bbff");
        newest.setStyle("-fx-background-color: #b6bbff");
        score.setStyle("-fx-background-color: #b6bbff");
    }

    @FXML
    void dairy(ActionEvent event) {

    }

    @FXML
    void expensive(ActionEvent event) throws FileNotFoundException {
        setProduct(2);
        expensive.setStyle("-fx-background-color: #019eff");
        cheapest.setStyle("-fx-background-color: #b6bbff");
        newest.setStyle("-fx-background-color: #b6bbff");
        score.setStyle("-fx-background-color: #b6bbff");
    }

    @FXML
    void fruits(ActionEvent event) {

    }

    @FXML
    void grocery(ActionEvent event) {

    }

    @FXML
    void newest(ActionEvent event) throws FileNotFoundException {
        selectedNewest();
        newest.setStyle("-fx-background-color: #019eff");
        expensive.setStyle("-fx-background-color: #b6bbff");
        cheapest.setStyle("-fx-background-color: #b6bbff");
        score.setStyle("-fx-background-color: #b6bbff");
        }

    @FXML
    void nuts(ActionEvent event) {

    }

    int v=2;
    @FXML
    void price(ActionEvent event) {
        if (v==2) {
            pricePane.setStyle("-fx-background-color: #9617bd");
            pricePane.setVisible(true);
            minHide.setVisible(true);
            maxHide.setVisible(true);
            applyFilter.setVisible(true);
            v=1;
        }
        else if (v==1) {
            pricePane.setStyle("-fx-background-color: null");
            pricePane.setVisible(false);
            minHide.setVisible(false);
            maxHide.setVisible(false);
            applyFilter.setVisible(false);
            v=2;
        }
    }

    @FXML
    void protein(ActionEvent event) {

    }

    @FXML
    void readyFood(ActionEvent event) {

    }

    @FXML
    void score(ActionEvent event) throws FileNotFoundException {
      setProduct(3);
        score.setStyle("-fx-background-color: #019eff");
        expensive.setStyle("-fx-background-color: #b6bbff");
        cheapest.setStyle("-fx-background-color: #b6bbff");
        newest.setStyle("-fx-background-color: #b6bbff");
    }

    @FXML
    void search(MouseEvent event) {

    }

    @FXML
    void snacks(ActionEvent event) {

    }

    @FXML
    void spices(ActionEvent event) {

    }

    public void plus(int index,int j) {
        if (Information.getProducts().get(index).getNumberInCart() < Information.getProducts().get(index).getQuantity()) {
            Information.getProducts().get(index).setNumberInCart(Information.getProducts().get(index).getNumberInCart() + 1);
            quantity.get(j).setText("تعداد : " + Information.getProducts().get(index).getNumberInCart());
        }
    }
    public void minus(int index,int j){
        if (Information.getProducts().get(index).getNumberInCart()>0){
            Information.getProducts().get(index).setNumberInCart(Information.getProducts().get(index).getNumberInCart()-1);
            if (Information.getProducts().get(index).getNumberInCart()==0)quantity.get(j).setText("افزودن به سبد");
            else quantity.get(j).setText("تعداد : "+Information.getProducts().get(index).getNumberInCart());
        }
    }

    @FXML
    public void applyFilter(ActionEvent actionEvent) throws FileNotFoundException {

        grid.setHgap(30);
        grid.setVgap(50);
        grid.setPadding(new Insets(50));
        for (int i=0;i<Information.getProducts().size();i++){
            int j=i;
            grid.getChildren().removeIf(node -> GridPane.getRowIndex(node)==j/4 && GridPane.getColumnIndex(node)==j%4);
        }
        quantity=new ArrayList<>();
        int[]indexs= Methods.sortByPrice(Information.getProducts(),Double.parseDouble(minHide.getText()),Double.parseDouble(maxHide.getText()));
        for (int i=0;i<indexs.length;i++) {
            anchorPane.setPrefHeight((i/4+1)*500);
            grid.setPrefHeight((i/4+1)*499.99);
            ImageView imageView = new ImageView(new Image(new FileInputStream(Information.getProducts().get(indexs[i]).getAddressImage())));
            Text text = new Text(Information.getProducts().get(indexs[i]).getName()+"\n"+Information.getProducts().get(indexs[i]).getDescription());
            text.setFont(Font.font("serif",20));
            text.setTextAlignment(TextAlignment.CENTER);
            Button minus=new Button("-");
            minus.setFont(Font.font("serif",18));
            minus.setStyle("-fx-background-color: #ff0000");
            int index = i;
            minus.setOnAction(e -> {
                minus(index,index);
            });
            quantity.add(new Label());
            if (Information.getProducts().get(indexs[i]).getNumberInCart()==0)quantity.get(i).setText("افزودن به سبد");
            else quantity.get(i).setText("تعداد : "+Information.getProducts().get(indexs[i]).getNumberInCart());
            quantity.get(i).setFont(Font.font("Arial",20));
            quantity.get(i).setPrefSize(100,35);
            quantity.get(i).setAlignment(Pos.CENTER);
            Button plus=new Button("+");
            plus.setFont(Font.font("serif",18));
            plus.setStyle("-fx-background-color: #00ff00");
            plus.setOnAction(e -> {
                plus(index,index);
            });
            HBox hBox=new HBox(minus,quantity.get(i),plus);
            hBox.setAlignment(Pos.CENTER);
            Label label=new Label(Methods.moneyStandard(Information.getProducts().get(indexs[i]).getPrice())+" تومان");
            label.setPrefSize(250,100);
            label.setAlignment(Pos.CENTER);
            label.setPadding(new Insets(5));
            label.setFont(Font.font("serif",20));
            VBox vbox = new VBox(imageView, text,label, hBox);
            vbox.setAlignment(Pos.CENTER);
            vbox.setPrefSize(350,350);
            grid.add(vbox, i%4, i/4);
        }



        pricePane.setStyle("-fx-background-color: null");
        pricePane.setVisible(false);
        minHide.setVisible(false);
        maxHide.setVisible(false);
        applyFilter.setVisible(false);

        minHide.setText("");
        maxHide.setText("");




    }
}
