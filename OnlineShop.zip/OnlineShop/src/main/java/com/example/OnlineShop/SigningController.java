package com.example.OnlineShop;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.io.IOException;

public class SigningController {

    int role=1;


    @FXML
    private TextField confirmCodeField;

    @FXML
    private TextField emailField;

    @FXML
    private TextField firstNameField;

    @FXML
    private TextField lastNameField;

    @FXML
    private TextField passwordField;

    @FXML
    private TextField phoneNumberField;

    @FXML
    private Label setCodeSend;

    @FXML
    private TextField userNameField;

    @FXML
    private Button customer;

    @FXML
    private Button seller;

    @FXML
    void customerButton(ActionEvent event) {
        customer.setStyle("-fx-background-color: #11DECB");
        seller.setStyle("-fx-background-color: #ffffff");
        role=1;
    }

    public void send(ActionEvent actionEvent) {
        confirmCodeField.setEditable(true);
    }

    @FXML
    void loginButton(ActionEvent event) throws IOException {

        boolean permission=true;

        firstNameField.setStyle("-fx-border-color: white; -fx-border-width: 1px; -fx-background-radius: 20px; -fx-border-radius: 20px ");
        lastNameField.setStyle("-fx-border-color: white; -fx-border-width: 1px; -fx-background-radius: 20px; -fx-border-radius: 20px ");
        phoneNumberField.setStyle("-fx-border-color: white; -fx-border-width: 1px; -fx-background-radius: 20px; -fx-border-radius: 20px ");
        userNameField.setStyle("-fx-border-color: white; -fx-border-width: 1px; -fx-background-radius: 20px; -fx-border-radius: 20px ");
        passwordField.setStyle("-fx-border-color: white; -fx-border-width: 1px; -fx-background-radius: 20px; -fx-border-radius: 20px ");
        emailField.setStyle("-fx-border-color: white; -fx-border-width: 1px; -fx-background-radius: 20px; -fx-border-radius: 20px ");
        confirmCodeField.setStyle("-fx-border-color: white; -fx-border-width: 1px; -fx-background-radius: 20px; -fx-border-radius: 20px ");


        if(firstNameField.getText().length()>15||firstNameField.getText().length()<3){
            permission=false;
            firstNameField.setStyle("-fx-border-color: red; -fx-border-width: 2px; -fx-background-radius: 20px; -fx-border-radius: 20px ");
        }
        if (lastNameField.getText().length()>15||lastNameField.getText().length()<3){
            permission=false;
            lastNameField.setStyle("-fx-border-color: red; -fx-border-width: 2px; -fx-background-radius: 20px; -fx-border-radius: 20px ");
        }
        if (phoneNumberField.getText().length()!=11 || !Methods.checkFieldText(phoneNumberField.getText())){
            permission=false;
            phoneNumberField.setStyle("-fx-border-color: red; -fx-border-width: 2px; -fx-background-radius: 20px; -fx-border-radius: 20px ");
        }

        if ((userNameField.getText().length()>15 || userNameField.getText().length()<5) || Methods.searchProperty("userName",userNameField.getText(),0)){
            permission=false;
            userNameField.setStyle("-fx-border-color: red; -fx-border-width: 2px; -fx-background-radius: 20px; -fx-border-radius: 20px ");
        }
        if (passwordField.getText().length()>15 || passwordField.getText().length()<5){
            permission=false;
            passwordField.setStyle("-fx-border-color: red; -fx-border-width: 2px; -fx-background-radius: 20px; -fx-border-radius: 20px ");
        }

        int x=emailField.getText().indexOf("@gmail.com");
        if ((emailField.getText().length()==0 || !emailField.getText().contains("@gmail.com") || emailField.getText().length()>x+10) || Methods.searchProperty("email",emailField.getText(),role)){
            permission=false;
            emailField.setStyle("-fx-border-color: red; -fx-border-width: 2px; -fx-background-radius: 20px; -fx-border-radius: 20px ");
        }

        int code=54321;
        if (confirmCodeField.getText().length()!=5 || !Methods.checkFieldText(confirmCodeField.getText()) || Integer.parseInt(confirmCodeField.getText())!=code ){
            permission=false;
            confirmCodeField.setStyle("-fx-border-color: red; -fx-border-width: 2px; -fx-background-radius: 20px; -fx-border-radius: 20px ");
        }


        if (permission){
            Methods.stage.close();
            if (role==1) {
                Information.getCustomer().add(new Customer(firstNameField.getText(), lastNameField.getText(), phoneNumberField.getText(), userNameField.getText(), passwordField.getText(), emailField.getText()));
            }
            if (role==2){
                Information.getSeller().add(new Seller(firstNameField.getText(), lastNameField.getText(), phoneNumberField.getText(), userNameField.getText(), passwordField.getText(), emailField.getText()));
            }
            Scene scene = new Scene(Methods.loader("Login.fxml").load(), 500, 600);
            Methods.stage.setScene(scene);
            Methods.stage.setFullScreen(true);
            Methods.stage.show();
        }

    }

    @FXML
    void sellerButton(ActionEvent event) {
        seller.setStyle("-fx-background-color: #11DECB");
        customer.setStyle("-fx-background-color: #ffffff");
        role=2;
    }


    @FXML
    void back() throws IOException {
        Methods.stage.close();
        Scene scene = new Scene(Methods.loader("Login.fxml").load(), 500, 600);
        Methods.stage.setScene(scene);
        Methods.stage.setFullScreen(true);
        Methods.stage.show();
    }

}
