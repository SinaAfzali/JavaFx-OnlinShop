package com.example.OnlineShop;

import java.util.ArrayList;

public class Seller {
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String role;
    private String userName;
    private String password;
    private String email;

    private ArrayList<String> discountCode=new ArrayList<>();

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getRole() {
        return role;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public ArrayList<String> getDiscountCode() {
        return discountCode;
    }

    public void addDiscountCode(String discountCode) {
        if (getDiscountCode().size()<6){
            getDiscountCode().add(discountCode);
        }
    }

    public String getUserName() {
        return userName;
    }

    public String getPassword() {
        return password;
    }

    public String getEmail() {
        return email;
    }




    public Seller(String firstName, String lastName, String phoneNumber, String userName, String password, String email){
        this.role="فروشنده";
        this.firstName=firstName;
        this.lastName=lastName;
        this.phoneNumber=phoneNumber;
        this.userName=userName;
        this.password=password;
        this.email=email;
    }

}
