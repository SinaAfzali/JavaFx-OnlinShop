package com.example.OnlineShop;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;

public class Main extends Application {
    @Override
    public void start(Stage primaryStage) throws IOException {
        Scene scene = new Scene(Methods.loader("MainPage.fxml").load(), 500, 600);
        Methods.stage.setScene(scene);
        Methods.stage.setFullScreen(true);
        Methods.stage.show();

        Information.getProducts().add(new Product("روغن مایع",2,60000,"src/main/resources/com/example/image/1.jpg","خواروبار","800 گرمی لادن بدون پالم"));
        Information.getProducts().add(new Product("کیسه برنج",5,650000,"src/main/resources/com/example/image/2.jpg","خواروبار"," ده کیلوگرمی طبیعت"));
        Information.getProducts().add(new Product("شیر کم چرب",2,30000,"src/main/resources/com/example/image/3.jpg","لبنیات","یک و نیم لیتری میهن"));
        Information.getProducts().add(new Product("حبوبات",5,75000,"src/main/resources/com/example/image/4.jpg","خواروبار","بسته یک و نیم کیلویی"));
        Information.getProducts().add(new Product("پفک نمکی",2,15000,"src/main/resources/com/example/image/5.jpg","تنقلات","حاوی پودر پنیر"));
        Information.getProducts().add(new Product("نوشابه کوکاکولا",5,25000,"src/main/resources/com/example/image/6.jpg","نوشیدنی","یک و نیم لیتری گازدار"));
        Information.getProducts().add(new Product("مزمز",5,20000,"src/main/resources/com/example/image/7.jpg","آجیل و خشکبار","مغز تخمه آفتابگردان"));
        Information.getProducts().get(0).setScore(4.48);
        Information.getProducts().get(1).setScore(3.55);
        Information.getProducts().get(2).setScore(4.9);
        Information.getProducts().get(3).setScore(4.75);
        Information.getProducts().get(4).setScore(3.32);
        Information.getProducts().get(5).setScore(2.65);
        Information.getProducts().get(6).setScore(4.22);


    }

    public static void main(String[] args) {
        launch();
    }
}