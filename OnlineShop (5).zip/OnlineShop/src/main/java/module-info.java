module com.example.OnlineShop {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires org.kordamp.bootstrapfx.core;
    requires javax.mail.api;
    requires activation;

    opens com.example.OnlineShop to javafx.fxml;
    exports com.example.OnlineShop;
}