package com.example.OnlineShop;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class productController implements Initializable {

    @FXML
    public Label number;
    @FXML
    public Label name;
    @FXML
    public Label explanation;
    @FXML
    public Label category;
    @FXML

    public Label seller;
    @FXML
    public Label score;
    @FXML
    public ImageView image;
    @FXML
    public Label price;
    @FXML
    private Button point1;

    @FXML
    private Button point2;

    @FXML
    private Button point3;

    @FXML
    private Button point4;

    @FXML
    private Button point5;

    @FXML
    private TextArea theReciveBox;

    @FXML
    private TextArea theSendBox;

    @FXML
    void setBack(MouseEvent event) throws IOException {
        Scene scene = new Scene(Methods.loader("MainPage.fxml").load(), 500, 600);
        Methods.stage.setScene(scene);
        Methods.stage.setFullScreen(true);
        Methods.stage.show();
    }

    @FXML
    void setDecreas(ActionEvent event) {
        if (Information.getProducts().get(Information.INDEX).getNumberInCart()>0){
            Information.getProducts().get(Information.INDEX).setNumberInCart(Information.getProducts().get(Information.INDEX).getNumberInCart()-1);
            if (Information.getProducts().get(Information.INDEX).getNumberInCart()==0)number.setText("افزودن به سبد");
            else number.setText("تعداد : "+Information.getProducts().get(Information.INDEX).getNumberInCart());
            Database.updateProduct(Information.getProducts().get(Information.INDEX));
        }
    }

    @FXML
    void setIncreas(ActionEvent event) {
        if (Information.getProducts().get(Information.INDEX).getNumberInCart() < Information.getProducts().get(Information.INDEX).getQuantity()) {
            Information.getProducts().get(Information.INDEX).setNumberInCart(Information.getProducts().get(Information.INDEX).getNumberInCart() + 1);
            number.setText("تعداد : " + Information.getProducts().get(Information.INDEX).getNumberInCart());
            Database.updateProduct(Information.getProducts().get(Information.INDEX));
        }
    }

    @FXML
    void setPoint(ActionEvent event) {

    }

    String  text = "";
    @FXML
    void setSend(ActionEvent event) throws IOException {

        if (true){
            text += Information.getUserName() + " : " +"\n"+ theSendBox.getText() + "\n\n\n";

            theReciveBox.setText(text);

            theSendBox.setText("");

        }else {
            Scene scene = new Scene(Methods.loader("Login.fxml").load(), 500, 600);
            Methods.stage.setScene(scene);
            Methods.stage.setFullScreen(true);
            Methods.stage.show();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        String s = "";

        if (Information.product.getNumberInCart()>0)s = "تعداد : "+String.valueOf(Information.product.getNumberInCart());
        else s = "افزودن به سبد";

        number.setText(s);

        name.setText("نام  : "+Information.product.getName());
        explanation.setText("توضیحات  : "+Information.product.getDescription());
        category.setText("دسته بندی : "+Information.product.getCategory());
        seller.setText("فروشنده : "+Information.product.getUserNameSeller());
        score.setText("امتیاز محصول : "+Information.product.getScore());

        number.setPrefSize(150,30);
        number.setAlignment(Pos.CENTER);
        try {
            image.setImage(new Image(new FileInputStream(Information.product.getAddressImage())));
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }

        price.setText("قیمت : "+Methods.moneyStandard(Information.product.getPrice())+" تومان");


        theReciveBox.setFont(new Font("serif",20));

    }
}
