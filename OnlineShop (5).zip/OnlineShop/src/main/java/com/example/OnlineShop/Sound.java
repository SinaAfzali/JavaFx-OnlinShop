//package com.example.OnlineShop;
//import javafx.scene.media.Media;
//import javafx.scene.media.MediaPlayer;
//import javafx.util.Duration;
//
//public class Sound {
//    public static void main(String[] args) {
//        String musicFile = "path/to/your/file.mp3"; // مسیر فایل صوتی خود را وارد کنید
//        Media sound = new Media(new File(musicFile).toURI().toString());
//        MediaPlayer mediaPlayer = new MediaPlayer(sound);
//
//        mediaPlayer.setOnReady(new Runnable() {
//            public void run() {
//                mediaPlayer.play();
//            }
//        });
//    }
//}