package com.example.OnlineShop;

public class Comment {
    String userName;

    String codeOfProduct;
    String textComment;
    boolean bought;

    public Comment(String userName,String textComment,String codeOfProduct,boolean bought){
        this.userName=userName;
        this.textComment=textComment;
        this.bought=bought;
        this.codeOfProduct=codeOfProduct;
    }
}
