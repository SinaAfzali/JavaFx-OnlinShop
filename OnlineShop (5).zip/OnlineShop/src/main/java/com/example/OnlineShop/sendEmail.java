package com.example.OnlineShop;
 interface sendEmail {
    void send(String message,String email);
}
