package com.example.OnlineShop;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class InformationOfMembersController implements Initializable {

    @FXML
    private TextField addressField;

    @FXML
    private Label addressLabel;

    @FXML
    private Button createButton;

    @FXML
    private GridPane grid;

    @FXML
    private Pane infoPane;

    @FXML
    private Label nameLabel;

    @FXML
    private TextField namefield;

    @FXML
    private Label setTitle;

    @FXML
    private AnchorPane warehousePane;

    @FXML
    void back(MouseEvent event)throws IOException {
        Scene scene = new Scene(Methods.loader("AdminAccount.fxml").load(), 500, 600);
        Methods.stage.setScene(scene);
        Methods.stage.setFullScreen(true);
        Methods.stage.show();
    }


    public void setInformation(){



        for (int i=0;i<Information.getProducts().size();i++){
            int j=i;
            grid.getChildren().removeIf(node -> GridPane.getRowIndex(node)==j && GridPane.getColumnIndex(node)==j);
        }

        for (int i=0;i<Information.getPersons().size();i++){

            double money=0;

            if (Information.getPersons().get(i) instanceof Customer){
                for (int j = 0; j < Information.getTransactions().size(); j++) {
                    if (Information.getTransactions().get(j).getCustomer().equals(Information.getPersons().get(i).getUserName())) {
                        money+=Information.getTransactions().get(j).getPrice();
                    }
                }

            }else if(Information.getPersons().get(i) instanceof Seller){
                for (int j = 0; j < Information.getTransactions().size(); j++) {
                    if (Information.getTransactions().get(j).getSeller().equals(Information.getPersons().get(i).getUserName())) {
                        money+=Information.getTransactions().get(j).getPrice();
                    }
                }
            }


            warehousePane.setPrefHeight((i+1)*60);
            grid.setPrefHeight((i+1)*60);
            Button numberLabel=new Button(Information.getPersons().get(i).getUserName());
            numberLabel.setPrefSize(120,60);
            Button managerLabel=new Button(Information.getPersons().get(i).getRole());
            managerLabel.setPrefSize(150,60);
            Button addressLabel=new Button(Methods.moneyStandard(money)+" تومان");
            addressLabel.setPrefSize(250,60);
            Button nameLabel=new Button(Methods.moneyStandard(Information.getPersons().get(i).getMoney())+" تومان");
            nameLabel.setPrefSize(150,60);

            HBox hBox=new HBox(nameLabel,addressLabel,managerLabel,numberLabel);


            hBox.setPadding(new Insets(5));
            grid.add(hBox,0,i);

        }
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setInformation();
    }
}
