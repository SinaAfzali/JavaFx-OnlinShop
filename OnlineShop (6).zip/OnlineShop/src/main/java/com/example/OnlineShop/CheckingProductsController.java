package com.example.OnlineShop;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.util.Duration;
import org.controlsfx.control.Notifications;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class CheckingProductsController implements Initializable {

    @FXML
    private AnchorPane anchorPane;

    @FXML
    private GridPane grid;


    @FXML
    void backIcon(MouseEvent event)throws IOException {
        Scene scene = new Scene(Methods.loader("AdminAccount.fxml").load(), 500, 600);
        Methods.stage.setScene(scene);
        Methods.stage.setFullScreen(true);
        Methods.stage.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(10));
        for (int i=0;i<Information.getProducts().size();i++){
            int j=i;
            grid.getChildren().removeIf(node -> GridPane.getRowIndex(node)==j/4 && GridPane.getColumnIndex(node)==j%4);
        }

        int[]indexs;
       indexs=Methods.sortByNewest(0);

        for (int i=0;i<indexs.length;i++) {
            anchorPane.setPrefHeight((i/4+1)*500);
            grid.setPrefHeight((i/4+1)*499.99);

            ImageView imageView = null;
            try {
                imageView = new ImageView(new Image(new FileInputStream(Information.getProducts().get(indexs[i]).getAddressImage())));
            } catch (FileNotFoundException e) {
                throw new RuntimeException(e);
            }

            Text text = new Text(Information.getProducts().get(indexs[i]).getName()+"\n"+Information.getProducts().get(indexs[i]).getDescription());
            text.setFont(Font.font("serif",20));
            text.setTextAlignment(TextAlignment.CENTER);
            Button delete=new Button("حذف محصول");
            delete.setFont(Font.font("Arial",24));
            delete.setStyle("-fx-background-color: #ff0000");
            delete.setPrefSize(250,30);
            delete.setTextAlignment(TextAlignment.CENTER);
            int index=indexs[i];
            int index2 = i;
            delete.setOnAction(e -> {
                try {
                    delete(index);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            });

            imageView.setOnMouseClicked(e->{
                try {
                    goToProductPage(Information.getProducts().get(index),index2);
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            });

            HBox hBox=new HBox(delete);
            hBox.setAlignment(Pos.CENTER);
            Label label=new Label(Methods.moneyStandard(Information.getProducts().get(indexs[i]).getPrice())+" تومان");
            label.setPrefSize(250,100);
            label.setAlignment(Pos.CENTER);
            label.setPadding(new Insets(5));
            label.setFont(Font.font("serif",20));
            VBox vbox = new VBox(imageView, text,label, hBox);
            vbox.setAlignment(Pos.CENTER);
            vbox.setPrefSize(350,350);
            grid.add(vbox, i%4, i/4);
        }
    }

    public void delete(int index) throws SQLException {

        Notifications notificationBuilder = Notifications.create()
                .title("")
                .text("آیا مطمعن هستید که میخواهید این محصول را حذف کنید؟ \n برای حذف محصول (کلیک کنید)                       ")
                .darkStyle()
                .graphic(null)
                .hideAfter(Duration.seconds(15))
                .position(Pos.CENTER)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent a) {
                        Information.getProducts().remove(index);
                        try {
                            Database.deleteProduct(Information.getProducts().get(index));
                            Methods.notification("محصول با موفقیت حذف شد",7);
                            Scene scene = new Scene(Methods.loader("checkingProducts.fxml").load(), 500, 600);
                            Methods.stage.setScene(scene);
                            Methods.stage.setFullScreen(true);
                            Methods.stage.show();


                        } catch (SQLException e) {
                            throw new RuntimeException(e);
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    }
                });
        notificationBuilder.showInformation();
    }


    public void goToProductPage(Product product,int index) throws IOException {

        Information.product=product;

        Information.INDEX=index;

        Scene scene = new Scene(Methods.loader("product.fxml").load(), 500, 600);
        Methods.stage.setScene(scene);
        Methods.stage.setFullScreen(true);
        Methods.stage.show();
    }



}
