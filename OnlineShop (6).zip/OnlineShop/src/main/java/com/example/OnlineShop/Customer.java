package com.example.OnlineShop;

import java.util.ArrayList;

public final class Customer extends Person{


    public Customer(String firstName, String lastName, String phoneNumber, String userName, String password, String email){
        setRole("خریدار");
        setFirstName(firstName);
        setLastName(lastName);
        setPhoneNumber(phoneNumber);
        setUserName(userName);
        setPassword(password);
        setEmail(email);
    }

}
