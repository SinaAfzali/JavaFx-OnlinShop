package com.example.demo13;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class HelloApplication extends Application {

    private TextField usernameField;
    private PasswordField passwordField;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Login or Sign In");

        // Create UI components
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(10));
        gridPane.setHgap(10);
        gridPane.setVgap(10);

        Label usernameLabel = new Label("Username : ");
        Label passwordLabel = new Label("Password : ");

        usernameField = new TextField();
        passwordField = new PasswordField();

        // Apply custom CSS style to the text fields
        usernameField.setStyle("-fx-background-radius: 20; -fx-background-color: #5DA8E5;");
        passwordField.setStyle("-fx-background-radius: 20; -fx-background-color: #5DA8E5;");

        Button loginButton = new Button("Login");
        loginButton.setOnAction(event -> login());

        Button signInButton = new Button("Sign In");
        signInButton.setOnAction(event -> signIn());

        gridPane.add(usernameLabel, 0, 0);
        gridPane.add(usernameField, 1, 0);
        gridPane.add(passwordLabel, 0, 1);
        gridPane.add(passwordField, 1, 1);
        gridPane.add(loginButton, 0, 2);
        gridPane.add(signInButton, 1, 2);

        Scene scene = new Scene(gridPane, 300, 150);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void login() {
        String username = usernameField.getText();
        String password = passwordField.getText();

        // Perform login logic here
        // You can check the username and password against a database or hardcoded values

        if (username.equals("admin") && password.equals("password")) {
            System.out.println("Login successful!");
            usernameField.setStyle("-fx-background-radius: 20; -fx-background-color: green;");
            passwordField.setStyle("-fx-background-radius: 20; -fx-background-color: green;");
            // Open the main application window or perform other actions
        } else {
            if(!username.equals("admin")) {
                usernameField.setStyle("-fx-background-radius: 20; -fx-background-color: red;");
                System.out.println("Invalid credentials. Please try again.");
                // Display an error message or perform other actions
            }
            if (username.equals("admin")) {
                usernameField.setStyle("-fx-background-radius: 20; -fx-background-color: green;");
            }
            if(!password.equals("password")){
                passwordField.setStyle("-fx-background-radius: 20; -fx-background-color: red;");
                System.out.println("Invalid credentials. Please try again.");
                // Display an error message or perform other actions
            }
            if (password.equals("password")) {
                passwordField.setStyle("-fx-background-radius: 20; -fx-background-color: green;");
            }
        }
    }

    private void signIn() {
        String username = usernameField.getText();
        String password = passwordField.getText();

        // Perform sign-in logic here
        // You can save the new username and password to a database or perform other actions

        System.out.println("Sign-in successful!");
        // Display a success message or perform other actions
    }

    public static void main(String[] args) {
        launch(args);
    }
}
