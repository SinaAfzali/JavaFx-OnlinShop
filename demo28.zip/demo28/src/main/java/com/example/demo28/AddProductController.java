package com.example.demo28;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;

import java.io.File;

public class AddProductController {


    @FXML
    private CheckBox beveragesCheck;

    @FXML
    private CheckBox breakfastCheck;

    @FXML
    private CheckBox dairyCheck;

    @FXML
    private CheckBox groceryCheck;

    @FXML
    private CheckBox snacksCheck;

    @FXML
    private CheckBox proteinCheck;

    @FXML
    private CheckBox spicesCheck;

    @FXML
    private CheckBox fruitsCheck;

    @FXML
    private CheckBox readyFoodCheck;

    @FXML
    private CheckBox nutsCheck;





    @FXML
    private CheckBox Check;

    @FXML
    private ImageView backIcon;

    @FXML
    private TextField discriptionOfProductField;

    @FXML
    private TextField nameOfProductField;

    @FXML
    private TextField numberOfProductField;

    @FXML
    private TextField priceOfProductField;

    @FXML
    void beveragesCheck(ActionEvent event) {

    }

    @FXML
    void breakfastCheck(ActionEvent event) {

    }

    @FXML
    void confirmButton(ActionEvent event) {

    }



    @FXML
    void fruitsCheck(ActionEvent event) {

    }

    @FXML
    void groceryCheck(ActionEvent event) {

    }

    @FXML
    void nutsCheck(ActionEvent event) {

    }

    @FXML
    void proteinCheck(ActionEvent event) {

    }

    @FXML
    void readyFoodCheck(ActionEvent event) {

    }

    @FXML
    void snacksCheck(ActionEvent event) {

    }

    @FXML
    void spicesCheck(ActionEvent event) {

    }

    @FXML
    private ImageView imagePreview;

    @FXML
    void importImageButton(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Image");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg", "*.gif"));
        File selectedFile = fileChooser.showOpenDialog(null);
        if (selectedFile != null) {
            Image image = new Image(selectedFile.toURI().toString());
            imagePreview.setImage(image);

        }
    }

    @FXML
     void dairyCheck(ActionEvent actionEvent) {
    }



    @FXML
    private void handleCheckboxSelection(ActionEvent event) {
        CheckBox selectedCheckbox = (CheckBox) event.getSource();

        // Uncheck all checkboxes except the selected one
        if (selectedCheckbox != beveragesCheck) {
            beveragesCheck.setSelected(false);
        }
        if (selectedCheckbox != breakfastCheck) {
            breakfastCheck.setSelected(false);
        }
        if (selectedCheckbox != dairyCheck) {
            dairyCheck.setSelected(false);
        }
        if (selectedCheckbox !=groceryCheck ) {
            groceryCheck.setSelected(false);
        }
        if (selectedCheckbox !=fruitsCheck ) {
            fruitsCheck.setSelected(false);
        }
        if (selectedCheckbox !=snacksCheck ) {
            snacksCheck.setSelected(false);
        }
        if (selectedCheckbox !=nutsCheck ) {
            nutsCheck.setSelected(false);
        }
        if (selectedCheckbox !=proteinCheck ) {
            proteinCheck.setSelected(false);
        }
        if (selectedCheckbox !=readyFoodCheck ) {
            readyFoodCheck.setSelected(false);
        }
        if (selectedCheckbox !=spicesCheck) {
            spicesCheck.setSelected(false);
        }
    }

}
