package com.example.demo25;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;

public class Cart {

    @FXML
    private ImageView backIcon;

    @FXML
    private Label setCodeSend;

}
