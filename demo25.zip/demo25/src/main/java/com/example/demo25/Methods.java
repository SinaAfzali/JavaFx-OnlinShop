package com.example.demo25;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.util.Duration;
import org.controlsfx.control.Notifications;

import java.util.Random;

public class Methods {

    static Stage stage=new Stage();

    public static FXMLLoader loader(String fxml){
      return  new FXMLLoader(HelloApplication.class.getResource(fxml));
    }


    public static String imageRand(){
        Random random=new Random();
        int rand=random.nextInt(15)+1;
        return switch (rand) {
            case 1 -> "src/main/resources/com/example/image/14726.png";
            case 2 -> "src/main/resources/com/example/image/17624.png";
            case 3 -> "src/main/resources/com/example/image/18543.png";
            case 4 -> "src/main/resources/com/example/image/79199.png";
            case 5 -> "src/main/resources/com/example/image/21695.png";
            case 6 -> "src/main/resources/com/example/image/28642.png";
            case 7 -> "src/main/resources/com/example/image/33697.png";
            case 8 -> "src/main/resources/com/example/image/34837.png";
            case 9 -> "src/main/resources/com/example/image/43481.png";
            case 10 -> "src/main/resources/com/example/image/53763.png";
            case 11 -> "src/main/resources/com/example/image/59788.png";
            case 12 -> "src/main/resources/com/example/image/63598.png";
            case 13 -> "src/main/resources/com/example/image/72696.png";
            case 14 -> "src/main/resources/com/example/image/82473.png";
            case 15 -> "src/main/resources/com/example/image/91758.png";
            default -> "";
        };
    }

    public static String codeImageRand(String image){
        return switch (image) {
            case "src/main/resources/com/example/image/14726.png" -> "14726";
            case "src/main/resources/com/example/image/17624.png" -> "17624";
            case "src/main/resources/com/example/image/18543.png" -> "18543";
            case "src/main/resources/com/example/image/79199.png" -> "79199";
            case "src/main/resources/com/example/image/21695.png" -> "21695";
            case "src/main/resources/com/example/image/28642.png" -> "28642";
            case "src/main/resources/com/example/image/33697.png" -> "33697";
            case "src/main/resources/com/example/image/34837.png" -> "34837";
            case "src/main/resources/com/example/image/43481.png" -> "43481";
            case "src/main/resources/com/example/image/53763.png" -> "53763";
            case "src/main/resources/com/example/image/59788.png" -> "59788";
            case "src/main/resources/com/example/image/63598.png" -> "63598";
            case "src/main/resources/com/example/image/72696.png" -> "72696";
            case "src/main/resources/com/example/image/82473.png" -> "82473";
            case "src/main/resources/com/example/image/91758.png" -> "91758";
            default -> "";
        };
    }

//   public static boolean searchProperty(String item , String value , int role){
//       for (int i=0;i<Information.getCustomer().size();i++){
//           if (item.equals(Information.getCustomer().get(i).getUserName()))return true;
//       }
//           switch (item){
//               case "userName":
//               if(role==1 || role==0){
//                   for (int i = 0; i < Information.getCustomer().size(); i++) {
//                       if (value.equals(Information.getCustomer().get(i).getUserName())) return true;
//                   }
//               }
//               if (role==2 || role==0){
//                   for (int i = 0; i < Information.getSeller().size(); i++) {
//                       if (value.equals(Information.getSeller().get(i).getUserName())) return true;
//                   }
//               }
//               case "password":
//                   if(role==1 || role==0){
//                       for (int i = 0; i < Information.getCustomer().size(); i++) {
//                           if (value.equals(Information.getCustomer().get(i).getPassword())) return true;
//                       }
//                   }
//                   if (role==2 || role==0){
//                       for (int i = 0; i < Information.getSeller().size(); i++) {
//                           if (value.equals(Information.getSeller().get(i).getPassword())) return true;
//                       }
//                   }
//               case "email":
//                   if(role==1 || role==0){
//                       for (int i = 0; i < Information.getCustomer().size(); i++) {
//                           if (value.equals(Information.getCustomer().get(i).getEmail())) return true;
//                       }
//                   }
//                   if (role==2 || role==0){
//                       for (int i = 0; i < Information.getSeller().size(); i++) {
//                           if (value.equals(Information.getSeller().get(i).getEmail())) return true;
//                       }
//                   }
//           }
//        return false;
//   }
//
//
//    public static boolean checkFieldText(String s){
//        for (int i=0;i<s.length();i++){
//            if (s.charAt(i)>'9' || s.charAt(i)<'0')return false;
//        }
//        return true;
//    }
//
//
//    public static void notification(String text,int second){
//        Notifications notificationBuilder = Notifications.create()
//                .title("")
//                .text(text)
//                .hideAfter(Duration.seconds(second))
//                .position(Pos.TOP_CENTER)
//                .onAction(new EventHandler<ActionEvent>() {
//                    @Override
//                    public void handle(ActionEvent a) {
//                        //
//                    }
//                });
//
//        notificationBuilder.showInformation();
//    }

}
