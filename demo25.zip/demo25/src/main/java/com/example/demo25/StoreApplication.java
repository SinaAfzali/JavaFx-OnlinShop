package com.example.demo25;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class StoreApplication extends Application {

    private int totalProducts = 0;
    private double totalProfit = 0.0;

    private Label productsLabel;
    private Label profitLabel;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Foodstuffs Market Store");

        GridPane gridPane = createGridPane();
        VBox vbox = createVBox();

        VBox root = new VBox(gridPane, vbox);
        root.setAlignment(Pos.CENTER);
        root.setSpacing(20);
        root.setPadding(new Insets(20));

        Scene scene = new Scene(root, 400, 300);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private GridPane createGridPane() {
        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setHgap(10);
        gridPane.setVgap(10);

        Label titleLabel = new Label("Foodstuffs Market Store");
        titleLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
        GridPane.setColumnSpan(titleLabel, 2);
        gridPane.add(titleLabel, 0, 0);

        Label productsTitleLabel = new Label("Number of Products:");
        gridPane.add(productsTitleLabel, 0, 1);

        productsLabel = new Label(String.valueOf(totalProducts));
        gridPane.add(productsLabel, 1, 1);

        Label profitTitleLabel = new Label("Total Profit:");
        gridPane.add(profitTitleLabel, 0, 2);

        profitLabel = new Label(String.valueOf(totalProfit));
        gridPane.add(profitLabel, 1, 2);

        return gridPane;
    }

    private VBox createVBox() {
        VBox vbox = new VBox();
        vbox.setAlignment(Pos.CENTER);
        vbox.setSpacing(10);

        Label addProductLabel = new Label("Add Product");
        addProductLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        vbox.getChildren().add(addProductLabel);

        HBox hbox = new HBox();
        hbox.setAlignment(Pos.CENTER);
        hbox.setSpacing(5);

        Label nameLabel = new Label("Name:");
        TextField nameField = new TextField();

        Label priceLabel = new Label("Price:");
        TextField priceField = new TextField();

        Button addButton = new Button("Add");
        addButton.setOnAction(e -> {
            String name = nameField.getText();
            double price = Double.parseDouble(priceField.getText());

            addProduct(name, price);
            nameField.clear();
            priceField.clear();
        });

        hbox.getChildren().addAll(nameLabel, nameField, priceLabel, priceField, addButton);
        vbox.getChildren().add(hbox);

        return vbox;
    }

    private void addProduct(String name, double price) {
        totalProducts++;
        totalProfit += price;

        productsLabel.setText(String.valueOf(totalProducts));
        profitLabel.setText(String.valueOf(totalProfit));
    }

    public static void main(String[] args) {
        launch(args);
    }
}


