package com.example.demo25;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;

import java.io.File;


public class SellerAccountController {
    private boolean editMode = false;

    private String initialEmail;
    private boolean validateEmail(String email) {
        // Regular expression pattern for email validation
        String emailRegex = "^[A-Za-z0-9+_.-]+@(.+)$";
        return email.matches(emailRegex);
    }
    private String initialFirstName;
    private String initialLastName;
    private String initialPassword;
    private String initialPhone;
    private String initialRule;
    private String initialUsername;

    private FileChooser fileChooser;



    @FXML
    public void initialize() {
        // Initialization tasks and setup here
        fileChooser = new FileChooser();
        fileChooser.setTitle("Select Profile Image");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg")
        );
    }



    @FXML
    private ImageView changeProfile;

    @FXML
    private TextField emailField;

    @FXML
    private TextField firstNameField;

    @FXML
    private TextField lastNameField;

    @FXML
    private Label moneyField;

    @FXML
    private TextField passField;

    @FXML
    private TextField phoneField;

    @FXML
    private TextField ruleField;

    @FXML
    private TextField userField;

    @FXML
    void addProductButton(ActionEvent event) {

    }

    @FXML
    void bankAccounts(ActionEvent event) {

    }
//-----------------------------------------------------------
    @FXML
    void cancelButton(ActionEvent event) {
        if (editMode) {
            // Restore initial values
            emailField.setText(initialEmail);
            firstNameField.setText(initialFirstName);
            lastNameField.setText(initialLastName);
            passField.setText(initialPassword);
            phoneField.setText(initialPhone);
            ruleField.setText(initialRule);
            userField.setText(initialUsername);

            // Disable editing
            enableTextFields(false);
            editMode = false;
        }
    }

//---------------------------------------------------------
    @FXML
    void changeInformationButton(ActionEvent event) {
     editMode = true;
     enableTextFields(true);

        if (!editMode) {

            File selectedFile = fileChooser.showOpenDialog(null);

            if(selectedFile != null){

            }

            // Store initial values
            initialEmail = emailField.getText();
            initialFirstName = firstNameField.getText();
            initialLastName = lastNameField.getText();
            initialPassword = passField.getText();
            initialPhone = phoneField.getText();
            initialUsername = userField.getText();

            // Enable editing
            enableTextFields(true);
            editMode = true;
        }

    }
//-----------------------------------------------------------
    private void enableTextFields(boolean enable) {
        emailField.setEditable(enable);
        firstNameField.setEditable(enable);
        lastNameField.setEditable(enable);
        passField.setEditable(enable);
        phoneField.setEditable(enable);
        userField.setEditable(enable);
    }
//-----------------------------------------------------------

    @FXML
    void confirmButton(ActionEvent event) {

        if (editMode) {
            String email = emailField.getText();
            String firstName = firstNameField.getText();
            String lastName = lastNameField.getText();
            String password = passField.getText();
            String phone = phoneField.getText();
            String rule = ruleField.getText();
            String username = userField.getText();

            boolean isEmailValid = validateEmail(email);
            if (!isEmailValid) {
                // Display error for invalid email
                emailField.setStyle("-fx-border-color: red;");
                emailField.setStyle("-fx-background-radius: 20px");
                return; // Stop further processing
            }

            enableTextFields(false);

            editMode = false;
        }
    }
//-------------------------------------------------------------
    @FXML
    void creatAuctionButton(ActionEvent event) {

    }

    @FXML
    void returnIcon(MouseEvent event) {

    }

    @FXML
    void sellInformationButton(ActionEvent event) {

    }

    @FXML
    void takeMoney(ActionEvent event) {

    }

}
